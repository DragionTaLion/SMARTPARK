import React, { useState, useEffect, useRef } from 'react';
import { 
  Car, 
  LogIn, 
  LogOut, 
  Activity, 
  LayoutDashboard, 
  Settings, 
  Bell, 
  Search,
  CheckCircle2,
  Clock,
  Video,
  Download,
  Camera,
  Cpu,
  Save,
  Filter
} from 'lucide-react';

// --- Types ---
type LogEntry = {
  id: string;
  plate: string;
  time: Date;
  type: 'IN' | 'OUT';
  status: 'SUCCESS' | 'WARNING';
  imageUrl?: string;
};

// --- Mock Data Generator ---
const generateMockPlate = () => {
  const letters = 'ABCDEFGHKLMNPRSTUVXYZ';
  const numbers = '0123456789';
  const randomLetter = () => letters[Math.floor(Math.random() * letters.length)];
  const randomNumber = () => numbers[Math.floor(Math.random() * numbers.length)];
  
  return `30${randomLetter()}-${randomNumber()}${randomNumber()}${randomNumber()}.${randomNumber()}${randomNumber()}`;
};

export default function App() {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'history' | 'settings'>('dashboard');
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [stats, setStats] = useState({ inside: 142, entries: 45, exits: 32 });
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isScanning, setIsScanning] = useState(false);

  // --- Camera Setup ---
  useEffect(() => {
    let stream: MediaStream | null = null;
    
    const startCamera = async () => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({ video: true });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      } catch (err) {
        console.error("Lỗi truy cập camera:", err);
      }
    };

    // Only start camera if we are on the dashboard
    if (activeTab === 'dashboard') {
      startCamera();
    }

    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [activeTab]);

  // --- Simulate YOLO Detection ---
  useEffect(() => {
    const interval = setInterval(() => {
      setIsScanning(true);
      
      setTimeout(() => {
        const isEntry = Math.random() > 0.5;
        const newLog: LogEntry = {
          id: Math.random().toString(36).substr(2, 9),
          plate: generateMockPlate(),
          time: new Date(),
          type: isEntry ? 'IN' : 'OUT',
          status: 'SUCCESS',
        };

        setLogs(prev => [newLog, ...prev].slice(0, 50)); // Keep last 50 for history
        setStats(prev => ({
          inside: isEntry ? prev.inside + 1 : prev.inside - 1,
          entries: isEntry ? prev.entries + 1 : prev.entries,
          exits: !isEntry ? prev.exits + 1 : prev.exits,
        }));
        
        setIsScanning(false);
      }, 800); // Simulate processing time
      
    }, 5000); // Trigger every 5 seconds

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex h-screen bg-slate-50 font-sans text-slate-900">
      {/* --- Sidebar --- */}
      <aside className="w-64 bg-white border-r border-slate-200 flex flex-col shrink-0">
        <div className="p-6 flex items-center gap-3 border-b border-slate-100">
          <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white shadow-sm">
            <Car size={24} />
          </div>
          <div>
            <h1 className="font-bold text-lg tracking-tight">SmartPark</h1>
            <p className="text-xs text-slate-500 font-medium">ALPR System</p>
          </div>
        </div>
        
        <nav className="flex-1 p-4 space-y-1">
          <NavItem 
            icon={<LayoutDashboard size={20} />} 
            label="Tổng quan" 
            active={activeTab === 'dashboard'} 
            onClick={() => setActiveTab('dashboard')} 
          />
          <NavItem 
            icon={<Activity size={20} />} 
            label="Lịch sử xe" 
            active={activeTab === 'history'} 
            onClick={() => setActiveTab('history')} 
          />
          <NavItem 
            icon={<Settings size={20} />} 
            label="Cài đặt hệ thống" 
            active={activeTab === 'settings'} 
            onClick={() => setActiveTab('settings')} 
          />
        </nav>
        
        <div className="p-4 border-t border-slate-100">
          <div className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-slate-50 cursor-pointer transition-colors">
            <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center text-slate-600 font-medium text-sm">
              AD
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-slate-900 truncate">Admin</p>
              <p className="text-xs text-slate-500 truncate">admin@chungcu.vn</p>
            </div>
          </div>
        </div>
      </aside>

      {/* --- Main Content --- */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Top Header */}
        <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-8 shrink-0">
          <h2 className="text-xl font-semibold tracking-tight">
            {activeTab === 'dashboard' && 'Giám sát Trực tiếp'}
            {activeTab === 'history' && 'Lịch sử Ra Vào'}
            {activeTab === 'settings' && 'Cài đặt Hệ thống'}
          </h2>
          <div className="flex items-center gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input 
                type="text" 
                placeholder="Tìm biển số..." 
                className="pl-10 pr-4 py-2 bg-slate-100 border-transparent focus:bg-white focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 rounded-lg text-sm w-64 transition-all outline-none"
              />
            </div>
            <button className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-full transition-colors relative">
              <Bell size={20} />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
            </button>
          </div>
        </header>

        {/* Dynamic Content Area */}
        <div className="flex-1 overflow-auto p-8">
          
          {/* ================= DASHBOARD TAB ================= */}
          {activeTab === 'dashboard' && (
            <>
              {/* Stats Row */}
              <div className="grid grid-cols-3 gap-6 mb-8">
                <StatCard 
                  title="Xe đang trong bãi" 
                  value={stats.inside} 
                  icon={<Car size={24} className="text-indigo-600" />} 
                  trend="+3%" 
                />
                <StatCard 
                  title="Lượt vào hôm nay" 
                  value={stats.entries} 
                  icon={<LogIn size={24} className="text-emerald-600" />} 
                  trend="+12%" 
                />
                <StatCard 
                  title="Lượt ra hôm nay" 
                  value={stats.exits} 
                  icon={<LogOut size={24} className="text-orange-600" />} 
                  trend="-2%" 
                />
              </div>

              {/* Main Split View */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                
                {/* Camera Section */}
                <div className="lg:col-span-2 flex flex-col gap-4">
                  <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-200 flex flex-col h-full">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-semibold text-slate-800 flex items-center gap-2">
                        <Video size={18} className="text-slate-500" />
                        Camera Cổng Chính
                      </h3>
                      <div className="flex items-center gap-2">
                        <span className="relative flex h-3 w-3">
                          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                          <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
                        </span>
                        <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">Live</span>
                      </div>
                    </div>
                    
                    <div className="relative flex-1 bg-slate-900 rounded-xl overflow-hidden min-h-[400px]">
                      <video 
                        ref={videoRef} 
                        autoPlay 
                        playsInline 
                        muted 
                        className="absolute inset-0 w-full h-full object-cover"
                      />
                      
                      {/* Scanning Overlay Effect */}
                      {isScanning && (
                        <div className="absolute inset-0 pointer-events-none">
                          <div className="absolute top-0 left-0 w-full h-1 bg-indigo-500 shadow-[0_0_15px_rgba(99,102,241,0.8)] animate-[scan_1.5s_ease-in-out_infinite]"></div>
                          <div className="absolute inset-0 bg-indigo-500/10"></div>
                          
                          {/* Bounding Box Simulation */}
                          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-24 border-2 border-indigo-500 rounded-lg">
                            <div className="absolute -top-1 -left-1 w-3 h-3 border-t-2 border-l-2 border-indigo-400"></div>
                            <div className="absolute -top-1 -right-1 w-3 h-3 border-t-2 border-r-2 border-indigo-400"></div>
                            <div className="absolute -bottom-1 -left-1 w-3 h-3 border-b-2 border-l-2 border-indigo-400"></div>
                            <div className="absolute -bottom-1 -right-1 w-3 h-3 border-b-2 border-r-2 border-indigo-400"></div>
                            <div className="absolute -top-6 left-0 bg-indigo-500 text-white text-[10px] font-mono px-2 py-0.5 rounded-sm">
                              DETECTING...
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Recent Logs Section */}
                <div className="bg-white rounded-2xl shadow-sm border border-slate-200 flex flex-col h-[500px]">
                  <div className="p-5 border-b border-slate-100 flex items-center justify-between">
                    <h3 className="font-semibold text-slate-800 flex items-center gap-2">
                      <Clock size={18} className="text-slate-500" />
                      Hoạt động gần đây
                    </h3>
                    <button 
                      onClick={() => setActiveTab('history')}
                      className="text-xs font-medium text-indigo-600 hover:text-indigo-700"
                    >
                      Xem tất cả
                    </button>
                  </div>
                  
                  <div className="flex-1 overflow-y-auto p-2">
                    {logs.length === 0 ? (
                      <div className="h-full flex flex-col items-center justify-center text-slate-400">
                        <Activity size={32} className="mb-2 opacity-50" />
                        <p className="text-sm">Chưa có dữ liệu</p>
                      </div>
                    ) : (
                      <div className="space-y-1">
                        {logs.slice(0, 10).map((log) => (
                          <div key={log.id} className="flex items-center gap-4 p-3 hover:bg-slate-50 rounded-xl transition-colors group">
                            <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
                              log.type === 'IN' ? 'bg-emerald-100 text-emerald-600' : 'bg-orange-100 text-orange-600'
                            }`}>
                              {log.type === 'IN' ? <LogIn size={18} /> : <LogOut size={18} />}
                            </div>
                            
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center justify-between mb-1">
                                <span className="font-mono font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded text-sm border border-slate-200">
                                  {log.plate}
                                </span>
                                <span className="text-xs font-medium text-slate-500">
                                  {log.time.toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                                </span>
                              </div>
                              <div className="flex items-center gap-1.5">
                                <CheckCircle2 size={14} className="text-emerald-500" />
                                <span className="text-xs text-slate-500">
                                  {log.type === 'IN' ? 'Đã vào bãi' : 'Đã ra bãi'}
                                </span>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

              </div>
            </>
          )}

          {/* ================= HISTORY TAB ================= */}
          {activeTab === 'history' && (
            <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden flex flex-col h-full">
              <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
                <div className="flex items-center gap-4">
                  <div className="relative">
                    <Filter className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                    <select className="pl-9 pr-8 py-2 bg-white border border-slate-200 text-sm rounded-lg outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 appearance-none font-medium text-slate-700">
                      <option>Tất cả trạng thái</option>
                      <option>Chỉ xe vào</option>
                      <option>Chỉ xe ra</option>
                    </select>
                  </div>
                  <div className="relative">
                    <Clock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                    <select className="pl-9 pr-8 py-2 bg-white border border-slate-200 text-sm rounded-lg outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 appearance-none font-medium text-slate-700">
                      <option>Hôm nay</option>
                      <option>7 ngày qua</option>
                      <option>Tháng này</option>
                    </select>
                  </div>
                </div>
                <button className="flex items-center gap-2 bg-indigo-50 text-indigo-700 px-4 py-2 rounded-lg text-sm font-medium hover:bg-indigo-100 transition-colors border border-indigo-100">
                  <Download size={16} /> Xuất Excel
                </button>
              </div>
              
              <div className="flex-1 overflow-auto">
                <table className="w-full text-left border-collapse">
                  <thead className="sticky top-0 bg-white z-10 shadow-sm">
                    <tr className="text-slate-500 text-xs uppercase tracking-wider border-b border-slate-200">
                      <th className="p-4 font-medium">Biển số</th>
                      <th className="p-4 font-medium">Thời gian</th>
                      <th className="p-4 font-medium">Loại</th>
                      <th className="p-4 font-medium">Trạng thái</th>
                      <th className="p-4 font-medium text-right">Hành động</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-sm">
                    {logs.map(log => (
                      <tr key={log.id} className="hover:bg-slate-50/50 transition-colors">
                        <td className="p-4 font-mono font-bold text-slate-900">{log.plate}</td>
                        <td className="p-4 text-slate-600 font-medium">
                          {log.time.toLocaleDateString('vi-VN')} <span className="text-slate-400 mx-1">•</span> {log.time.toLocaleTimeString('vi-VN')}
                        </td>
                        <td className="p-4">
                          <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold ${
                            log.type === 'IN' ? 'bg-emerald-100 text-emerald-700' : 'bg-orange-100 text-orange-700'
                          }`}>
                            {log.type === 'IN' ? <LogIn size={12} /> : <LogOut size={12} />}
                            {log.type === 'IN' ? 'VÀO BÃI' : 'RA BÃI'}
                          </span>
                        </td>
                        <td className="p-4">
                          <span className="inline-flex items-center gap-1.5 text-emerald-600 text-xs font-medium bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-100">
                            <CheckCircle2 size={14} /> Hợp lệ
                          </span>
                        </td>
                        <td className="p-4 text-right">
                          <button className="text-indigo-600 hover:text-indigo-800 font-medium text-xs bg-indigo-50 hover:bg-indigo-100 px-3 py-1.5 rounded-lg transition-colors">
                            Chi tiết
                          </button>
                        </td>
                      </tr>
                    ))}
                    {logs.length === 0 && (
                      <tr>
                        <td colSpan={5} className="p-12 text-center text-slate-400">
                          <Activity size={48} className="mx-auto mb-4 opacity-20" />
                          <p>Chưa có dữ liệu lịch sử</p>
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* ================= SETTINGS TAB ================= */}
          {activeTab === 'settings' && (
            <div className="max-w-4xl mx-auto space-y-6 pb-12">
              {/* Camera Settings */}
              <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
                <div className="p-5 border-b border-slate-100 flex items-center gap-4 bg-slate-50/50">
                  <div className="w-12 h-12 rounded-xl bg-indigo-100 flex items-center justify-center text-indigo-600 shrink-0">
                    <Camera size={24} />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-800 text-lg">Cấu hình Camera</h3>
                    <p className="text-sm text-slate-500">Quản lý thiết bị ghi hình và độ phân giải luồng video</p>
                  </div>
                </div>
                <div className="p-6 space-y-5">
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">Nguồn Camera</label>
                    <select className="w-full bg-white border border-slate-300 rounded-xl px-4 py-3 text-sm outline-none focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/10 transition-all font-medium text-slate-700">
                      <option>Camera Cổng Chính (IP: 192.168.1.101)</option>
                      <option>Camera Cổng Phụ (IP: 192.168.1.102)</option>
                      <option>Webcam Tích hợp (Local)</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">Độ phân giải luồng video</label>
                    <select className="w-full bg-white border border-slate-300 rounded-xl px-4 py-3 text-sm outline-none focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/10 transition-all font-medium text-slate-700">
                      <option>1080p (1920x1080) - Khuyên dùng</option>
                      <option>720p (1280x720) - Tiết kiệm băng thông</option>
                      <option>4K (3840x2160) - Yêu cầu mạng tốc độ cao</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* AI Settings */}
              <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
                <div className="p-5 border-b border-slate-100 flex items-center gap-4 bg-slate-50/50">
                  <div className="w-12 h-12 rounded-xl bg-emerald-100 flex items-center justify-center text-emerald-600 shrink-0">
                    <Cpu size={24} />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-800 text-lg">Cấu hình AI (YOLO)</h3>
                    <p className="text-sm text-slate-500">Tinh chỉnh mô hình nhận diện biển số và độ nhạy</p>
                  </div>
                </div>
                <div className="p-6 space-y-6">
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">Mô hình nhận diện</label>
                    <select className="w-full bg-white border border-slate-300 rounded-xl px-4 py-3 text-sm outline-none focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/10 transition-all font-medium text-slate-700">
                      <option>YOLOv8n (Nhanh, độ chính xác khá)</option>
                      <option selected>YOLOv8s (Cân bằng) - Đang sử dụng</option>
                      <option>YOLOv8m (Chậm, độ chính xác cao)</option>
                    </select>
                  </div>
                  <div className="pt-2">
                    <div className="flex justify-between mb-3">
                      <label className="block text-sm font-semibold text-slate-700">Ngưỡng tin cậy (Confidence Threshold)</label>
                      <span className="text-sm font-bold text-indigo-600 bg-indigo-50 px-3 py-1 rounded-lg">75%</span>
                    </div>
                    <input type="range" min="0" max="100" defaultValue="75" className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-indigo-600" />
                    <p className="text-sm text-slate-500 mt-3">
                      Hệ thống chỉ ghi nhận các biển số có độ tin cậy trên mức này để giảm thiểu sai sót do mờ, lóa sáng.
                    </p>
                  </div>
                </div>
              </div>

              {/* Save Actions */}
              <div className="flex justify-end gap-4 pt-4">
                <button className="px-6 py-3 text-sm font-bold text-slate-600 bg-white border border-slate-300 rounded-xl hover:bg-slate-50 transition-colors">
                  Hủy thay đổi
                </button>
                <button className="px-6 py-3 text-sm font-bold text-white bg-indigo-600 rounded-xl hover:bg-indigo-700 transition-colors flex items-center gap-2 shadow-sm shadow-indigo-200">
                  <Save size={18} />
                  Lưu cấu hình
                </button>
              </div>
            </div>
          )}

        </div>
      </main>
    </div>
  );
}

// --- Subcomponents ---

function NavItem({ 
  icon, 
  label, 
  active = false, 
  onClick 
}: { 
  icon: React.ReactNode, 
  label: string, 
  active?: boolean,
  onClick?: () => void
}) {
  return (
    <button 
      onClick={onClick}
      className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all ${
        active 
          ? 'bg-indigo-50 text-indigo-700 shadow-sm border border-indigo-100' 
          : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900 border border-transparent'
      }`}
    >
      {icon}
      {label}
    </button>
  );
}

function StatCard({ title, value, icon, trend }: { title: string, value: number, icon: React.ReactNode, trend: string }) {
  const isPositive = trend.startsWith('+');
  
  return (
    <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 flex items-center gap-5">
      <div className="w-14 h-14 rounded-2xl bg-slate-50 flex items-center justify-center border border-slate-100 shrink-0">
        {icon}
      </div>
      <div>
        <p className="text-sm font-medium text-slate-500 mb-1">{title}</p>
        <div className="flex items-baseline gap-2">
          <h4 className="text-3xl font-bold text-slate-900 tracking-tight">{value}</h4>
          <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${
            isPositive ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'
          }`}>
            {trend}
          </span>
        </div>
      </div>
    </div>
  );
}
